package com.example.prak2;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;

public class ResultActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_result);

        Double sisi = getIntent().getExtras().getDouble("sisi");

        if(getIntent().getExtras().getString("status").equals("volume")) {
            Intent data = new Intent();
            data.putExtra("result", sisi*sisi*sisi);
            setResult(1, data);
            finish();
        }else if(getIntent().getExtras().getString("status").equals("luas")){
            Intent data = new Intent();
            data.putExtra("result", 6*sisi*sisi);
            setResult(1, data);
            finish();
        }
    }
}