package com.example.prak2;

import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;

public class MainActivity extends AppCompatActivity {
    private EditText edtSisi;
    private Button btnVolume, btnLuas;
    private TextView txtResult;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        this.edtSisi = findViewById(R.id.edt_sisi);
        this.btnVolume = findViewById(R.id.btn_volume);
        this.btnLuas = findViewById(R.id.btn_luas);
        this.txtResult = findViewById(R.id.txt_result);

        btnVolume.setOnClickListener(action -> {
            Intent i = new Intent(this, ResultActivity.class);
            i.putExtra("sisi", Double.parseDouble(edtSisi.getText().toString().trim()));
            i.putExtra("status", "volume");
            startActivityForResult(i, 1);
        });

        btnLuas.setOnClickListener(action -> {
            Intent i = new Intent(this, ResultActivity.class);
            i.putExtra("sisi", Double.parseDouble(edtSisi.getText().toString().trim()));
            i.putExtra("status", "luas");
            startActivityForResult(i, 1);
        });
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);

        Double result = data.getExtras().getDouble("result");
        txtResult.setText("Hasil : ".concat(result.toString()));
    }
}